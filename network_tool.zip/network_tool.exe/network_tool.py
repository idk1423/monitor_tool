import pydivert
import threading
import argparse
from collections import defaultdict

running = False
stats = defaultdict(int)

# Популярные сервисы и их порты
popular_ports = {
    443: "HTTPS (YouTube, Discord, Roblox, Steam, …)",
    80: "HTTP",
    5222: "XMPP / Chat",
    3074: "Xbox / Games",
    27015: "Steam / Games",
}

def monitor():
    global running
    print("=== Network Monitor Started ===")

    with pydivert.WinDivert("tcp") as w:
        while running:
            packet = w.recv()

            if packet.ip and packet.tcp:
                port = packet.dst_port
                stats[port] += 1
                service = popular_ports.get(port, "Other")
                print(f"{packet.src_addr} -> {packet.dst_addr} | {port} ({service})")

            w.send(packet)

def start_monitor():
    global running
    if not running:
        running = True
        t = threading.Thread(target=monitor)
        t.start()
        print("Monitor enabled. Press Ctrl+C to stop.")
    else:
        print("Monitor already running.")

def stop_monitor():
    global running
    running = False
    print("Monitor disabled.")

def show_stats():
    print("\n=== Traffic Statistics ===")
    for port, count in stats.items():
        name = popular_ports.get(port, "Other")
        print(f"{port} ({name}) : {count} packets")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", action="store_true", help="Start network monitor")
    parser.add_argument("--stats", action="store_true", help="Show packet statistics")
    args = parser.parse_args()

    if args.start:
        start_monitor()
        try:
            while True:
                pass
        except KeyboardInterrupt:
            stop_monitor()

    if args.stats:
        show_stats()

if name == "main":
    main()
