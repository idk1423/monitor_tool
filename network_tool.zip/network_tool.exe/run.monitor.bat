@echo off
:: Запуск network tool в командной строке
network_tool.exe --start
pause